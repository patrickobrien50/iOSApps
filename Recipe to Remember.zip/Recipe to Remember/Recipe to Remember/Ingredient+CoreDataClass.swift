//
//  Ingredient+CoreDataClass.swift
//  Recipe to Remember
//
//  Created by Patrick O'Brien on 6/25/17.
//  Copyright © 2017 Patrick O'Brien. All rights reserved.
//

import Foundation
import CoreData

@objc(Ingredient)
public class Ingredient: NSManagedObject {

}
