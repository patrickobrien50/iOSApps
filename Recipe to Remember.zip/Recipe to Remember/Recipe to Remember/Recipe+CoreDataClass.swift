//
//  Recipe+CoreDataClass.swift
//  Recipe to Remember
//
//  Created by Patrick O'Brien on 6/25/17.
//  Copyright © 2017 Patrick O'Brien. All rights reserved.
//

import Foundation
import CoreData

@objc(Recipe)
public class Recipe: NSManagedObject {

}
